package com.example.kurs_vasilev;

public class Cabinets {
    public int id;
    public String number;
    public String description;

    public Cabinets(int id, String number, String description){
        this.id = id;
        this.number = number;
        this.description = description;
    }
}
