package com.example.kurs_vasilev;

public class News {
    public int id;
    public String title;
    public String url;

    public News(int id, String title, String url){
        this.id = id;
        this.title = title;
        this.url = url;
    }

}
